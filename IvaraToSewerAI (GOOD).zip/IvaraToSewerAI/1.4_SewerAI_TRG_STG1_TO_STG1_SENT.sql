--Update the workorder to SEND in both staging and delete the row in staging 1

CREATE OR REPLACE TRIGGER TRG_STG1_SENT_SYNC
FOR UPDATE OF FEED_STATUS ON CUSTOMERDATA.EPSEWERAI_WOT_STG1
COMPOUND TRIGGER

  /* Hold TASK_UUID values that transitioned to 'SENT' during this statement */
  TYPE t_uuid_tab IS TABLE OF RAW(16);
  g_to_delete t_uuid_tab := t_uuid_tab();

AFTER EACH ROW IS
BEGIN
  /* Only act on transition to 'SENT' (avoid churn if it was already 'SENT') */
  IF :NEW.FEED_STATUS = 'SENT'
     AND ( :OLD.FEED_STATUS IS NULL OR :OLD.FEED_STATUS <> 'SENT' )
  THEN
    /* 1) Push change to the source staging table */
    UPDATE CUSTOMERDATA.EPSEWERAI_WOT_STG s
       SET s.FEED_STATUS = 'SENT'
     WHERE s.WORKORDER_UUID = :NEW.TASK_UUID;

    /* 2) Queue this STG1 row for deletion after the statement completes */
    g_to_delete.EXTEND;
    g_to_delete(g_to_delete.LAST) := :NEW.TASK_UUID;
  END IF;
END AFTER EACH ROW;

AFTER STATEMENT IS
BEGIN
  /* Delete only those rows that changed to SENT in this statement */
  IF g_to_delete.COUNT > 0 THEN
    FOR i IN 1 .. g_to_delete.COUNT LOOP
      DELETE FROM CUSTOMERDATA.EPSEWERAI_WOT_STG1
       WHERE TASK_UUID = g_to_delete(i)
         AND FEED_STATUS = 'SENT';  -- defensive: ensure it is still SENT
    END LOOP;
  END IF;
END AFTER STATEMENT;

END TRG_STG1_SENT_SYNC;
