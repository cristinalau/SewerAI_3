CREATE OR REPLACE TRIGGER TRG_WOT_STG_TO_STG1
FOR INSERT OR UPDATE OF FEED_STATUS ON CUSTOMERDATA.EPSEWERAI_WOT_STG
COMPOUND TRIGGER

  ---------------------------------------------------------------------------
  -- Keep one "driver" status per WORKORDER_UUID during the statement.
  -- Map key = hex(WORKORDER_UUID), value = normalized FEED_STATUS ('NEW','UPDATED','SENT')
  ---------------------------------------------------------------------------
  TYPE t_status_map IS TABLE OF VARCHAR2(50) INDEX BY VARCHAR2(64);
  g_status_by_wo t_status_map;

  FUNCTION norm_status(p IN VARCHAR2) RETURN VARCHAR2 IS
    v VARCHAR2(50) := TRIM(UPPER(p));
  BEGIN
    IF v = 'SEND' THEN
      RETURN 'SENT';
    ELSIF v IN ('NEW','UPDATED','SENT') THEN
      RETURN v;
    ELSE
      RETURN NULL;
    END IF;
  END norm_status;

  PROCEDURE remember_driver(p_wo RAW, p_status VARCHAR2) IS
    v_hex VARCHAR2(64);
    v_s   VARCHAR2(50);
  BEGIN
    IF p_wo IS NULL THEN
      RETURN;
    END IF;
    v_s := norm_status(p_status);
    IF v_s IS NULL THEN
      RETURN;
    END IF;
    v_hex := RAWTOHEX(p_wo);
    -- "Last one wins" for multiple rows of the same WO within the same statement
    g_status_by_wo(v_hex) := v_s;
  END remember_driver;

  BEFORE STATEMENT IS
  BEGIN
    g_status_by_wo.DELETE;
  END BEFORE STATEMENT;

  AFTER EACH ROW IS
  BEGIN
    -- Fire for ANY inserted row, or FEED_STATUS updated to NEW/UPDATED/SENT.
    -- We only record the WORKORDER_UUID and the driver row's FEED_STATUS.
    IF INSERTING THEN
      remember_driver(:NEW.WORKORDER_UUID, :NEW.FEED_STATUS);
    ELSIF UPDATING('FEED_STATUS') THEN
      remember_driver(:NEW.WORKORDER_UUID, :NEW.FEED_STATUS);
    END IF;
  END AFTER EACH ROW;

  AFTER STATEMENT IS
    v_key      VARCHAR2(64);
    v_wo_uuid  RAW(16);
    v_status   VARCHAR2(50);
  BEGIN
    v_key := g_status_by_wo.FIRST;
    WHILE v_key IS NOT NULL LOOP
      v_wo_uuid := HEXTORAW(v_key);
      v_status  := g_status_by_wo(v_key);

      -----------------------------------------------------------------------
      -- Upsert ONE row in STG1 for this WO: payload from Task #1 in STG,
      -- but FEED_STATUS comes from the driver row that triggered this sync.
      -----------------------------------------------------------------------
      MERGE INTO CUSTOMERDATA.EPSEWERAI_WOT_STG1 s1
      USING (
        SELECT
          s.WORKORDER_UUID       AS WORKORDER_UUID,     -- maps to STG1.TASK_UUID
          s.WOTASKTITLE          AS WOTASKTITLE,
          s.PLNDSTRTDATE_DTTM    AS PLNDSTRTDATE_DTTM,
          s.PLNDCOMPDATE_DTTM    AS PLNDCOMPDATE_DTTM,
          s.WORKCLASSIFI_OI      AS WORKCLASSIFI_OI,
          v_status               AS FEED_STATUS         -- <- driver status
        FROM (
          SELECT stg.*,
                 ROW_NUMBER() OVER (
                   PARTITION BY stg.WORKORDER_UUID
                   ORDER BY stg.TASK_UUID              -- deterministic among Task #1 duplicates
                 ) rn
            FROM CUSTOMERDATA.EPSEWERAI_WOT_STG stg
           WHERE stg.WORKORDER_UUID = v_wo_uuid
             AND stg.TASKNUMBER     = 1
        ) s
       WHERE s.rn = 1
      ) src
      ON (s1.TASK_UUID = src.WORKORDER_UUID)

      WHEN MATCHED THEN
        UPDATE SET
          s1.WOTASKTITLE        = src.WOTASKTITLE,
          s1.PLNDSTRTDATE_DTTM  = src.PLNDSTRTDATE_DTTM,
          s1.PLNDCOMPDATE_DTTM  = src.PLNDCOMPDATE_DTTM,
          s1.WORKCLASSIFI_OI    = src.WORKCLASSIFI_OI,
          s1.FEED_STATUS        = src.FEED_STATUS
        WHERE
              NVL(s1.WOTASKTITLE, '~') <> NVL(src.WOTASKTITLE, '~')
           OR NVL(s1.PLNDSTRTDATE_DTTM, DATE '1900-01-01') <> NVL(src.PLNDSTRTDATE_DTTM, DATE '1900-01-01')
           OR NVL(s1.PLNDCOMPDATE_DTTM, DATE '1900-01-01') <> NVL(src.PLNDCOMPDATE_DTTM, DATE '1900-01-01')
           OR NVL(s1.WORKCLASSIFI_OI, -1) <> NVL(src.WORKCLASSIFI_OI, -1)
           OR NVL(s1.FEED_STATUS, '~') <> NVL(src.FEED_STATUS, '~')

      WHEN NOT MATCHED THEN
        INSERT (
          TASK_UUID,
          WOTASKTITLE,
          PLNDSTRTDATE_DTTM,
          PLNDCOMPDATE_DTTM,
          WORKCLASSIFI_OI,
          FEED_STATUS
        )
        VALUES (
          src.WORKORDER_UUID,
          src.WOTASKTITLE,
          src.PLNDSTRTDATE_DTTM,
          src.PLNDCOMPDATE_DTTM,
          src.WORKCLASSIFI_OI,
          src.FEED_STATUS
        );

      v_key := g_status_by_wo.NEXT(v_key);
    END LOOP;
  END AFTER STATEMENT;

END TRG_WOT_STG_TO_STG1;
