------------------------------------------------------------
-- Step 1: Drop staging table if exists (CUSTOMERDATA)
------------------------------------------------------------
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG PURGE';
EXCEPTION
    WHEN OTHERS THEN
        NULL; -- expected if first run
END;
/
------------------------------------------------------------
-- Step 2: Create staging table (clean version)
------------------------------------------------------------
--DROP TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG
CREATE TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG
(
    TASK_UUID           RAW(16)    DEFAULT SYS_GUID() NOT NULL ENABLE,
    WORKORDER_UUID      RAW(16),
    WONUMBER            VARCHAR2(100 BYTE),
    TASKNUMBER          NUMBER,
    WOTASKTITLE         VARCHAR2(503 BYTE),
    PLNDCOMPDATE_DTTM   DATE,
    PLNDSTRTDATE_DTTM   DATE,
    WORKCLASSIFI_OI     NUMBER,
    FEED_STATUS         VARCHAR2(50 BYTE)
);

------------------------------------------------------------
-- Step 3: Comments
------------------------------------------------------------
COMMENT ON TABLE  CUSTOMERDATA.EPSEWERAI_WOT_STG IS
'Staging for Work Order Tasks feed (trigger-driven).';

COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.TASK_UUID         IS 'Task UUID (RAW16).';
COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.WORKORDER_UUID    IS 'Work Order UUID (RAW16).';
COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.WONUMBER          IS 'External Work Order Number.';
COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.TASKNUMBER        IS 'Work Order Task Number.';
COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.WOTASKTITLE       IS 'WO or Task Title.';
COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.PLNDCOMPDATE_DTTM IS 'Planned completion date/time.';
COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.PLNDSTRTDATE_DTTM IS 'Planned start date/time.';
COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.WORKCLASSIFI_OI   IS 'Classification OI.';
COMMENT ON COLUMN CUSTOMERDATA.EPSEWERAI_WOT_STG.FEED_STATUS       IS 'NEW | UPDATED | SENT | etc.';

------------------------------------------------------------
-- Step 4: Indexes
------------------------------------------------------------

-- Primary matching key for MERGE:
CREATE UNIQUE INDEX CUSTOMERDATA.IX_EPSEWERAI_WOT_STG_TASK_UUID
    ON CUSTOMERDATA.EPSEWERAI_WOT_STG (TASK_UUID);

-- Work Order lookups (for your max-effective-date logic):
CREATE INDEX CUSTOMERDATA.IX_EPSEWERAI_WOT_STG_WO_UUID
    ON CUSTOMERDATA.EPSEWERAI_WOT_STG (WORKORDER_UUID);

-- Optional analytics index:
CREATE INDEX CUSTOMERDATA.IX_EPSEWERAI_WOT_STG_WONUMBER
    ON CUSTOMERDATA.EPSEWERAI_WOT_STG (WONUMBER);

-- Feed status processing:
CREATE INDEX CUSTOMERDATA.IX_EPSEWERAI_WOT_STG_FEED_STATUS
    ON CUSTOMERDATA.EPSEWERAI_WOT_STG (FEED_STATUS);

-- Date-based filtering:
CREATE INDEX CUSTOMERDATA.IX_EPSEWERAI_WOT_STG_DATES
    ON CUSTOMERDATA.EPSEWERAI_WOT_STG (PLNDSTRTDATE_DTTM, PLNDCOMPDATE_DTTM);
    
select * from  CUSTOMERDATA.EPSEWERAI_WOT_STG order by 2, 1
